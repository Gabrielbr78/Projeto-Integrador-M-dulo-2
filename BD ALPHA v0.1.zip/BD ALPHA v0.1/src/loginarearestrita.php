<?php
    include "conexao.php";

    $login = $_POST["login"];
    $senha = $_POST["senha"];

    $logar = mysqli_query($conexao, "select * from usuarios where login = '$login'");

    $linha = mysqli_fetch_array($logar);

    if($linha){
        echo "<script>
            location.href = 'menu_admin.html'
        </script>";
    }else{
        echo "<script>
            alert('Login ou senha incorretos!')
            location.href = 'loginarearestrita.html'
        </script>"; 
    }
?>