<?php
    $banco = "projetointegrador";
    $usuario = "root";
    $senha = "";

    $conexao = mysqli_connect('localhost',$usuario,$senha,$banco);

    
?>